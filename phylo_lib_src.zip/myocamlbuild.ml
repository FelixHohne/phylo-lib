open Ocamlbuild_plugin
let () = dispatch Bisect_ppx_plugin.dispatch